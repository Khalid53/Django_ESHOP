from django.shortcuts import render, redirect
from django.shortcuts import render
from store.models.customer import Customer
from django.contrib.auth.hashers import make_password, check_password
from django.views import View


# Create your views here.

class AuthSignup(View):
    def get(self, request):
        return render(request, 'signup.html')

    def post(self, request):
        postData = request.POST
        first_name = postData.get('first_name')
        last_name = postData.get('last_name')
        phone = postData.get('phone')
        email = postData.get('email')
        password = postData.get('password')
        customer = Customer(first_name=first_name, last_name=last_name, phone=phone, email=email, password=password)
        # old data
        values = {
            'first_name': first_name,
            'last_name': last_name,
            'phone': phone,
            'email': email,
        }
        # validation
        error_message = self.validateCustomer(customer)
        # saving
        if not error_message:
            customer.password = make_password(customer.password)
            request.session['name'] = customer.last_name
            customer.save()
            return redirect('login')
        else:
            return render(request, 'signup.html', {'error': error_message, 'values': values})

    def validateCustomer(self, customer):
        error_message = None
        if not customer.first_name:
            error_message = "First name required !!"
        elif len(customer.first_name) < 3:
            error_message = "First name must be 3 char or more !!"
        elif not customer.last_name:
            error_message = "Last name required !!"
        elif len(customer.last_name) < 3:
            error_message = "Last name must be 3 char or more !!"
        elif not customer.phone:
            error_message = "Phone number required !!"
        elif len(customer.phone) < 10:
            error_message = "Phone number must be 10 char or more !!"
        elif not customer.email:
            error_message = "Email Address required !!"
        elif len(customer.email) < 2:
            error_message = "Email must be 2 char or more !!"
        elif not customer.password:
            error_message = "Password required !!"
        elif len(customer.password) < 6:
            error_message = "Password must be 6 char or more !!"
        elif Customer.objects.filter(email=customer.email).exists():
            error_message = "This email already exists, please give an new email !!"
        return error_message
