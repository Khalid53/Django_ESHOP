from django.shortcuts import render, redirect
from django.shortcuts import render
from store.models.product import Product
from django.views import View


# Create your views here.

class Cart(View):
    def get(self, request):
        cart = request.session.get('cart')
        if not cart:
            request.session['cart'] = {}
        ids = list(request.session.get('cart').keys())
        products = Product.get_products_by_id(ids)
        return render(request, 'cart.html', {'products': products})




