from django.shortcuts import render, redirect
from django.shortcuts import render
from store.models.product import Product
from store.models.order import Order
from django.views import View


# Create your views here.

class OrderView(View):
    def get(self, request):
        customer = request.session.get('customer')
        orders = Order\
            .objects\
            .filter(customer=customer)\
            .order_by('-id')

        return render(request, 'order.html', {'orders': orders})



