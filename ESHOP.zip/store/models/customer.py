from django.db import models
from .category import Category
import datetime
# Create your models here.

class Customer(models.Model):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    phone = models.CharField(max_length=30)
    email = models.EmailField(max_length=150)
    password = models.CharField(max_length=200)
    date = models.DateField(default=datetime.datetime.today)

    def __str__(self):
        return self.first_name

    @staticmethod
    def get_customer_By_email(email):
        try:
            return Customer.objects.get(email=email)
        except:
            return False

